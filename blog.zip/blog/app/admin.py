from django.contrib import admin

# Register your models here.
from app.models import User, Article, Leacots


class UserAdmin(admin.ModelAdmin):
    list_display = ['pk','username','password']
    search_fields = ['username']

class ArticleAdmin(admin.ModelAdmin):
    list_display = ['pk','title','intro','author']

class LeatcotsAdmin(admin.ModelAdmin):
    list_display = ['person','comment','leave_time']

admin.site.register(User,UserAdmin)
admin.site.register(Article,ArticleAdmin)
admin.site.register(Leacots,LeatcotsAdmin)