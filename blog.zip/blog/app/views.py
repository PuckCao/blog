import datetime

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.shortcuts import render, redirect

# Create your views here.
from django.urls import reverse

from app.forms import RegisterForm, CommentForm
from app.models import Article, User, Leacots


def index(request,page=1):
    return redirect('/1')

@login_required(login_url='/login/')
def leacots(request):
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = request.POST.get('comment')
            person = request.user.username
            lea = Leacots()
            lea.comment = comment
            lea.person = person
            lea.leave_time = datetime.datetime.now()
            lea.save()
        else:
            return render(request,'leacots.html',{'form':form})
    comments = Leacots.objects.all()
    leave = []
    for i in comments:
        temp = {}
        temp['comment'] = i.comment
        temp['person'] = i.person
        temp['leave_time'] = i.leave_time
        leave.append(temp)
    nums = len(leave)
    return render(request, 'leacots.html', {'leave':leave,'nums':nums})


def about(request):
    return render(request, 'templates/about.html')

def article(request,num):
    article = Article.objects.get(pk=num)
    title = article.title
    text = article.text

    return render(request, 'templates/details.html', locals())


def page(request,page=1):
    article = Article.objects.all()
    paginator = Paginator(article,5)
    pager = paginator.page(page)
    start = (page - 1) * 5
    return render(request, 'templates/index1.html', locals())



def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            data.pop('confirm')
            user = User.objects.create_user(**data)
            if user:
                return render(request, 'templates/regist.html')
            else:
                return render(request, 'templates/r.html', {'form':form})
        else:
            return render(request, 'templates/r.html', {'form':form})

    return render(request, 'r.html')


def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username','')
        password = request.POST.get('password','')
        user = authenticate(request,username=username,password=password)
        if user:
            login(request,user)
            return redirect(reverse('app:index'))
        else:
            return render(request, 'templates/login.html', {'msg': '用户名或密码错误'})
    return render(request, 'templates/login.html')



def user_logout(request):
    logout(request)
    return redirect(reverse('app:index'))

